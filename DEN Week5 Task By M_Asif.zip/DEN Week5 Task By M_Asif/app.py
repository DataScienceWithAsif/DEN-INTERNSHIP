import streamlit as st
import re, string, json, joblib, numpy as np
from gensim.models import Word2Vec
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
import os
import nltk
# Ensure NLTK resources
nltk.download('punkt', quiet=True)
nltk.download('wordnet', quiet=True)
import nltk
nltk.download('punkt')
nltk.download('punkt_tab')   # 🔑 This is the missing one
nltk.download('stopwords')
nltk.download('wordnet')


st.set_page_config(page_title="Text Classification (TF-IDF & Word2Vec)", page_icon="🧠", layout="centered")

# ----------- Load artifacts -----------
ART_DIR = "artifacts"
tfidf = joblib.load(os.path.join(ART_DIR, "tfidf_vectorizer.joblib"))
tfidf_logreg = joblib.load(os.path.join(ART_DIR, "tfidf_logreg.joblib"))
tfidf_nb = joblib.load(os.path.join(ART_DIR, "tfidf_nb.joblib"))

w2v = Word2Vec.load(os.path.join(ART_DIR, "word2vec.model"))
w2v_logreg = joblib.load(os.path.join(ART_DIR, "w2v_logreg.joblib"))
w2v_rf = joblib.load(os.path.join(ART_DIR, "w2v_rf.joblib"))

config = json.load(open(os.path.join(ART_DIR, "config.json")))
W2V_DIM = config["w2v_dim"]

# Stopwords file is optional (we don't strictly need it at inference)
# with open(os.path.join(ART_DIR, "stopwords.txt")) as f:
#     stopwords_list = set([w.strip() for w in f if w.strip()])

# ----------- Preprocessing -----------
url_pattern = re.compile(r"http\S+|www\.\S+")
html_pattern = re.compile(r"<.*?>")
num_pattern = re.compile(r"\d+")
punct_table = str.maketrans("", "", string.punctuation)
lemmatizer = WordNetLemmatizer()

def tokenize_only(text: str):
    text = text.lower()
    text = url_pattern.sub(" ", text)
    text = html_pattern.sub(" ", text)
    text = num_pattern.sub(" ", text)
    text = text.translate(punct_table)
    tokens = word_tokenize(text)
    tokens = [t for t in tokens if t.isalpha() and len(t) > 2]
    tokens = [lemmatizer.lemmatize(t) for t in tokens]
    return tokens

def clean_text(text: str) -> str:
    return " ".join(tokenize_only(text))

def doc_to_vec(tokens, model, dim):
    vecs = []
    for t in tokens:
        if t in model.wv:
            vecs.append(model.wv[t])
    if len(vecs) == 0:
        return np.zeros(dim)
    return np.mean(vecs, axis=0)

# ----------- UI -----------
st.title("🧠 Text Classification: TF-IDF & Word2Vec")
st.write("Binary classification demo (e.g., SMS Spam vs Ham). Choose a model and enter text.")

model_choice = st.selectbox(
    "Choose a model:",
    (
        "TFIDF + LogisticRegression (probabilities)",
        "TFIDF + MultinomialNB (probabilities)",
        "W2V + LogisticRegression (probabilities)",
        "W2V + RandomForest (probabilities)"
    )
)

user_text = st.text_area("Enter text to classify:", height=150, placeholder="e.g., Congratulations! You won a $1000 Walmart gift card...")
btn = st.button("Predict")

def predict_tfidf(text, clf):
    ct = clean_text(text)
    X = tfidf.transform([ct])
    pred = clf.predict(X)[0]
    proba = None
    if hasattr(clf, "predict_proba"):
        proba = clf.predict_proba(X)[0]
    return pred, proba

def predict_w2v(text, clf):
    tokens = tokenize_only(text)
    vec = doc_to_vec(tokens, w2v, W2V_DIM).reshape(1, -1)
    pred = clf.predict(vec)[0]
    proba = None
    if hasattr(clf, "predict_proba"):
        proba = clf.predict_proba(vec)[0]
    return pred, proba

label_map = {0: "ham (not spam)", 1: "spam"}

if btn and user_text.strip():
    if model_choice.startswith("TFIDF + LogisticRegression"):
        pred, proba = predict_tfidf(user_text, tfidf_logreg)
    elif model_choice.startswith("TFIDF + MultinomialNB"):
        pred, proba = predict_tfidf(user_text, tfidf_nb)
    elif model_choice.startswith("W2V + LogisticRegression"):
        pred, proba = predict_w2v(user_text, w2v_logreg)
    else:
        pred, proba = predict_w2v(user_text, w2v_rf)

    st.subheader("Prediction")
    st.write(f"**Class:** {label_map[pred]}")

    if proba is not None:
        st.write("**Probabilities:**")
        st.write(f"ham: {proba[0]:.3f} | spam: {proba[1]:.3f}")
        st.progress(int(proba[1]*100))
    else:
        st.caption("This model does not expose calibrated probabilities.")
